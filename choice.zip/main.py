from flask import Flask

app = Flask(__name__)


@app.route("/")
@app.route("/home")
def home():
    return '''<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <title>ничего</title>
                </head>
                <body>
                тут ничего нет
                </body>
                </html>'''


@app.route("/choice/<planet>")
def choice(planet):
    planet = planet.capitalize()
    length = {"Марс": "близком",
              "Меркурий": "среднем",
              "Венера": "близком",
              "Юпитер": "среднем",
              "Сатурн": "дальнем",
              "Уран": "очень даленьнем",
              "Нептун": "очень дальнем"}
    resource = {"Марс": "много",
                "Меркурий": "мало",
                "Венера": "среднее",
                "Юпитер": "среднее (только газы и алмазы)",
                "Сатурн": "малое (только газы)",
                "Уран": "мало",
                "Нептун": "мало"}
    water = {"Марс": "нет",
             "Меркурий": "нет",
             "Венера": "пар",
             "Юпитер": "нет",
             "Сатурн": "нет",
             "Уран": "оч много",
             "Нептун": "дофигища"}
    atmosphere = {"Марс": "не пригодна для человека",
                  "Меркурий": "нет",
                  "Венера": "нет",
                  "Юпитер": "нет",
                  "Сатурн": "нет",
                  "Уран": "нет",
                  "Нептун": "нет"}
    magnet = {"Марс": "слабое",
              "Меркурий": "нет",
              "Венера": "да",
              "Юпитер": "нет",
              "Сатурн": "нет",
              "Уран": "да",
              "Нептун": "да"}

    return f'''<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <title>Варианты выбора</title>
                    <link rel="stylesheet" href="static/css/style.css">
                </head>
                <body style="font-family:Arial">
                <h1>Вариант: {planet}</h1>
                <h2>Эта планета на {length[planet]} расстоянии от Земли;</h2>
                <div class="green">Количество ресурсов: {resource[planet]}</div>
                <div class="grey">Присутствие воды: {water[planet]} | Присутствие атмосферы: {atmosphere[planet]}</div>
                <div class="yellow">Присутствие магнитного поля: {magnet[planet]}</div>
                </body>
                </html>'''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')